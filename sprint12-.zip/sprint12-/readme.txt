
Link a Tableau Proyecto 12

https://public.tableau.com/app/profile/marco.estrada.ocampo/viz/proyecto12_17480366132190/Dashboard1?publish=yes

Link para el dashboard en tableau
